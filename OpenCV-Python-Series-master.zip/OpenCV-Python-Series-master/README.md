# OpenCV & Python Tutorial Series

Related code for the series on [YouTube](https://www.youtube.com/playlist?list=PLEsfXFp6DpzRyxnU-vfs3vk-61Wpt7bOS)

New to OpenCV? Try this: https://youtu.be/YY9f-6u2Q_c

### Learn OpenCV & Python Playlist: [https://www.youtube.com/playlist?list=PLEsfXFp6DpzRyxnU-vfs3vk-61Wpt7bOS](https://www.youtube.com/playlist?list=PLEsfXFp6DpzRyxnU-vfs3vk-61Wpt7bOS)

### Install OpenCV for Python on your system:
- Mac: https://youtu.be/iluST-V757A
- Windows: https://youtu.be/Fcc_jemaoNU
- Linux with Pi Awesome: https://kirr.co/sx77b7