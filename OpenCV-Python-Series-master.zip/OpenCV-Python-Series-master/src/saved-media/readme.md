This directory is purposefully left empty. We don't need to upload our saved media to github which allows the entire repo to be smaller. 

Images that are used for training purposes can be found under the "images" directory.